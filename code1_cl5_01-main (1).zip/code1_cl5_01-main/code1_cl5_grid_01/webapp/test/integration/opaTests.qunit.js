/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/grid01/code1cl5grid01/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
