sap.ui.define([
	"code1/cl5/grid01/code1cl5grid01/test/unit/controller/GridView.controller"
], function () {
	"use strict";
});
