sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1.cl5.edu08.code1cl5edu08.controller.App", {
      onInit() {
      }
  });
});