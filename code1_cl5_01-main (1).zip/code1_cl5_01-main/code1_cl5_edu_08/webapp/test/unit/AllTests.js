sap.ui.define([
	"code1/cl5/edu08/code1cl5edu08/test/unit/controller/Edu08View.controller"
], function () {
	"use strict";
});
