/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/edu08/code1cl5edu08/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
