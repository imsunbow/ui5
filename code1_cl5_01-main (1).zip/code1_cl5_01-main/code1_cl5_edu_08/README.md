## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Thu Oct 30 2025 09:10:36 GMT+0900 (한국 표준시)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.19.1|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>Basic|
|**Service Type**<br>None|
|**Service URL**<br>N/A|
|**Module Name**<br>code1_cl5_edu_08|
|**Application Title**<br>다중행의 JSON 모델 실습|
|**Namespace**<br>code1.cl5.edu08|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.141.3|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## code1_cl5_edu_08

Multi Row JSON Model Handling

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


