/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/resource01/code1cl5resource01/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
