sap.ui.define([
	"code1/cl5/resource01/code1cl5resource01/test/unit/controller/ResourceView.controller"
], function () {
	"use strict";
});
