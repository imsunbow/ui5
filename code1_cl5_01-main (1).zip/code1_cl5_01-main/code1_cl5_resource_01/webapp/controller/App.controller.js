sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1.cl5.resource01.code1cl5resource01.controller.App", {
      onInit() {
      }
  });
});