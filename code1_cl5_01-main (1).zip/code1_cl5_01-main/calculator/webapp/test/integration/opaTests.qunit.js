/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/edu01/calculator/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
