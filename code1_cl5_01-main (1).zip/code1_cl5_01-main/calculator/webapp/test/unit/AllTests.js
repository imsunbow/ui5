sap.ui.define([
	"code1/cl5/edu01/calculator/test/unit/controller/calculatorView.controller"
], function () {
	"use strict";
});
