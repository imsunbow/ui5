/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1cl5edu06/code1cl5edu06/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
