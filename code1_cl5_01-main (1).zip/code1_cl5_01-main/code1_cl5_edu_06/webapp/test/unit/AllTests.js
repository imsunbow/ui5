sap.ui.define([
	"code1cl5edu06/code1cl5edu06/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
