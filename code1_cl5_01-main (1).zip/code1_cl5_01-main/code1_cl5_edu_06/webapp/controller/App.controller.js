sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1cl5edu06.code1cl5edu06.controller.App", {
      onInit() {
      }
  });
});