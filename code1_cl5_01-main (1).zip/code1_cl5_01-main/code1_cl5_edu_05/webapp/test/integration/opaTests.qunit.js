/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/edu05/code1cl5edu05/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
