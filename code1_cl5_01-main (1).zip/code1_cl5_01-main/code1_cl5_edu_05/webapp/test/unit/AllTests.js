sap.ui.define([
	"code1/cl5/edu05/code1cl5edu05/test/unit/controller/Edu05View.controller"
], function () {
	"use strict";
});
