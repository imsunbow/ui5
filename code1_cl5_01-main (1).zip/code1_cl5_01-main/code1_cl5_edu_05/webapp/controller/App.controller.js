sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1.cl5.edu05.code1cl5edu05.controller.App", {
      onInit() {
      }
  });
});