/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code/cl5/edu04/code1cl5edu04/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
