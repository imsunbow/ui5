sap.ui.define([
	"code/cl5/edu04/code1cl5edu04/test/unit/controller/Edu04View.controller"
], function () {
	"use strict";
});
