sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code.cl5.edu04.code1cl5edu04.controller.App", {
      onInit() {
      }
  });
});