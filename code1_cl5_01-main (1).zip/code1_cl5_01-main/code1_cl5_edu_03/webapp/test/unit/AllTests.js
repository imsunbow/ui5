sap.ui.define([
	"code1/cl5/edu03/code1cl5edu03/test/unit/controller/Edu03View.controller"
], function () {
	"use strict";
});
