sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("coed1.cl5.route01.code1cl5route01.controller.App", {
      onInit() {
      }
  });
});