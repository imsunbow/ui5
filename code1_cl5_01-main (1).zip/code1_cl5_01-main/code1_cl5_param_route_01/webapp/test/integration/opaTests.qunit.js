/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/param/route01/code1cl5paramroute01/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
