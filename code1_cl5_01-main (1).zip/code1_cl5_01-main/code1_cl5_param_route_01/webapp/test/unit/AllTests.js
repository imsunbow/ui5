sap.ui.define([
	"code1/cl5/param/route01/code1cl5paramroute01/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
