sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1.cl5.param.route01.code1cl5paramroute01.controller.App", {
      onInit() {
      }
  });
});