sap.ui.define([
	"assignmentjson1/assignmetnjson1/test/unit/controller/assignment_JSON1.controller"
], function () {
	"use strict";
});
