/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["assignmentjson1/assignmetnjson1/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
