sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("assignmentjson1.assignmetnjson1.controller.App", {
      onInit() {
      }
  });
});