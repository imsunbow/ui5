/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/edu/basic/basic1103/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
