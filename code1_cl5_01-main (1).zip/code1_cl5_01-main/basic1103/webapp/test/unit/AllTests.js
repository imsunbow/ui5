sap.ui.define([
	"code1/cl5/edu/basic/basic1103/test/unit/controller/Basic1103.controller"
], function () {
	"use strict";
});
