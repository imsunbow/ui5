sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1.cl5.micro.chart01.code1cl5microchart01.controller.App", {
      onInit() {
      }
  });
});