/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/micro/chart01/code1cl5microchart01/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
