sap.ui.define([
	"code1/cl5/micro/chart01/code1cl5microchart01/test/unit/controller/chart_01.controller"
], function () {
	"use strict";
});
