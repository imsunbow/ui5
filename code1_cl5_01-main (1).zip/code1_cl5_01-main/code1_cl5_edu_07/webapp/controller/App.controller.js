sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1.cl5.edu07.code1cl5edu07.controller.App", {
      onInit() {
      }
  });
});