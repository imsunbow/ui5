/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/edu07/code1cl5edu07/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
