sap.ui.define([
	"code1/cl5/edu07/code1cl5edu07/test/unit/controller/Edu07View.controller"
], function () {
	"use strict";
});
