sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code1cl5edu02.code1cl5edu02.controller.App", {
      onInit() {
      }
  });
});