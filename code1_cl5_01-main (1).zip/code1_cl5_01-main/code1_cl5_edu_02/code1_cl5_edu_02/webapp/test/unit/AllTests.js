sap.ui.define([
	"code1cl5edu02/code1cl5edu02/test/unit/controller/code1_cl5_edu_02.controller"
], function () {
	"use strict";
});
