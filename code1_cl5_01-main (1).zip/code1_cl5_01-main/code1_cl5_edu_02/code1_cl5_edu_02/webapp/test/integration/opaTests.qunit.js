/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1cl5edu02/code1cl5edu02/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
