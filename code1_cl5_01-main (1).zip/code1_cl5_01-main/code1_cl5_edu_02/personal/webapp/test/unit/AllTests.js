sap.ui.define([
	"personal/test/unit/controller/personal_training.controller"
], function () {
	"use strict";
});
