sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("personal.controller.personal_training", {
        onInit() {
        }
    });
});