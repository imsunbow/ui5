sap.ui.define([
	"code1/cl5/calculator/code1cl5calculator/test/unit/controller/CalView.controller"
], function () {
	"use strict";
});
