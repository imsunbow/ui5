/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code1/cl5/calculator/code1cl5calculator/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
