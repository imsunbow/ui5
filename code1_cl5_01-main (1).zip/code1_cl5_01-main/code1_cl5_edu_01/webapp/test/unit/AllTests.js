sap.ui.define([
	"code1/cl5/edu01/code1cl5edu01/test/unit/controller/Edu01View.controller"
], function () {
	"use strict";
});
